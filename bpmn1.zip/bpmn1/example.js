const BpmnModdle = require('bpmn-moddle');

const moddle = new BpmnModdle();

const xmlStr =
  '<?xml version="1.0" encoding="UTF-8"?>' +
  '<bpmn2:definitions xmlns:bpmn2="http://www.omg.org/spec/BPMN/20100524/MODEL" ' +
                     'id="empty-definitions" ' +
                     'targetNamespace="http://bpmn.io/schema/bpmn">' +
  '</bpmn2:definitions>';


const {
  rootElement: definitions
} = moddle.fromXML(xmlStr);

// add a process to the diagram
const process = moddle.create('bpmn:Process', { id: 'MyProcess_1' });
definitions.get('rootElements').push(process);

// add a start event to the process
const startEvent = moddle.create('bpmn:StartEvent', { id: 'StartEvent_1' });
process.get('flowElements').push(startEvent);

// add an end event to the process
const endEvent = moddle.create('bpmn:EndEvent', { id: 'EndEvent_1' });
process.get('flowElements').push(endEvent);

// add a task to the process
const task = moddle.create('bpmn:Task', { id: 'Task_1' });
process.get('flowElements').push(task);

// add a sequence flow between start event and task
const sequenceFlow = moddle.create('bpmn:SequenceFlow', {
  id: 'SequenceFlow_1',
  sourceRef: startEvent,
  targetRef: task
});
process.get('flowElements').push(sequenceFlow);

// add a sequence flow between task and end event
const sequenceFlow2 = moddle.create('bpmn:SequenceFlow', {
  id: 'SequenceFlow_2',
  sourceRef: task,
  targetRef: endEvent
});
process.get('flowElements').push(sequenceFlow2);

// convert the updated process to XML string
const {
  xml: xmlStrUpdated
} =  moddle.toXML(definitions);

console.log(xmlStrUpdated);
